#!/usr/bin/env python
import sys
import simplejson as json
import os
import argparse
from elasticsearch import Elasticsearch, helpers

def connect_elasticsearch():
    es = None
    es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
    # if es.ping():
        # print('Connected ElasticSearch')
    # else:
        # print('Failed Connect ElasticSearch!')
    return es

def search():
    data = {"took": 40, "timed_out": "false", "_shards": {"total": 1, "successful": 1, "skipped": 0, "failed": 0}, "hits": {"total": {"value": 1, "relation": "eq"}, "max_score": 4.9625254, "hits": [{"_index": "kenh14", "_type": "_doc", "_id": "20190501125230046", "_score": 4.9625254, "_source": {"html": "http://kenh14.vn//justin-bieber-dang-anh-quang-cao-vong-co-co-ma-sao-lisa-blackpink-lai-chiem-toan-bo-spotlight-het-the-nay-20190501125230046.chn", "title": "Justin Bieber \u0111\u0103ng \u1ea3nh qu\u1ea3ng c\u00e1o v\u00f2ng c\u1ed5 c\u01a1 m\u00e0, sao Lisa (BLACKPINK) l\u1ea1i chi\u1ebfm to\u00e0n b\u1ed9 spotlight h\u1ebft th\u1ebf n\u00e0y", "time": "2019-05-01T15:27:43", "short_content": "M\u1ed9t b\u1ee9c \u1ea3nh c\u1ee7a Justin Bieber th\u00f4i m\u00e0 th\u00e0nh c\u00f4ng \u0111\u00f4i ba vi\u1ec7c. V\u1eeba s\u1eb5n ti\u1ec7n PR cho th\u01b0\u01a1ng hi\u1ec7u th\u1eddi trang c\u1ee7a anh ch\u00e0ng, v\u1eeba khoe \u0111\u01b0\u1ee3c g\u00f3c nghi\u00eang xinh \u0111\u1eb9p c\u1ee7a Lisa (BLACKPINK).", "full_content": "Duy\u00ean ph\u1eadn \u0111\u00fang l\u00e0 kh\u00f3 ai ng\u1edd \u0111\u01b0\u1ee3c m\u00e0. T\u1ea1i l\u1ec5 h\u1ed9i Coachella v\u1eeba qua,\u00a0\u00a0\u0111\u00e3 c\u00f3 kho\u1ea3ng th\u1eddi gian kh\u00f3 qu\u00ean khi v\u1eeba \u0111\u01b0\u1ee3c bi\u1ec3u di\u1ec5n v\u1edbi t\u01b0 c\u00e1ch ngh\u1ec7 s\u0129 t\u1ea1i l\u1ec5 h\u1ed9i \u00e2m nh\u1ea1c l\u1edbn nh\u1ea5t h\u00e0nh tinh n\u00e0y, l\u1ea1i v\u1eeba \u0111\u01b0\u1ee3c h\u01b0\u1edfng th\u1ee5 b\u1ea7u kh\u00f4ng kh\u00ed l\u1ec5 h\u1ed9i nh\u01b0 nh\u1eefng ng\u01b0\u1eddi b\u00ecnh th\u01b0\u1eddng...\u00a0M\u00e0 c\u0169ng kh\u00f4ng h\u1eb3n l\u00e0 b\u00ecnh th\u01b0\u1eddng cho l\u1eafm, c\u00e1c c\u00f4 n\u00e0ng c\u1ee7a BLACKPINK, \u0111\u1eb7c bi\u1ec7t l\u00e0 3 th\u00e0nh vi\u00ean Lisa, Jennie, Ros\u00e9 \u0111\u00e3 c\u00f3 c\u01a1 h\u1ed9i g\u1eb7p g\u1ee1 v\u00e0 \"qu\u1ea9y\" nhi\u1ec7t t\u00ecnh v\u1edbi r\u1ea5t nhi\u1ec1u ng\u00f4i sao n\u1ed5i ti\u1ebfng. Th\u1eadm ch\u00ed c\u00f2n ch\u1ee5p \u1ea3nh r\u1ed3i \u0111\u0103ng l\u00ean instagram th\u1ea3 tim qua l\u1ea1i \u0111\u1ee7 ki\u1ec3u r\u1ea5t danh ch\u00ednh ng\u00f4n thu\u1eadn y h\u1ec7t nh\u01b0 1 b\u1eefa ti\u1ec7c giao l\u01b0u v\u1edbi ng\u01b0\u1eddi n\u1ed5i ti\u1ebfng Hollywood c\u1ee7a BLACKPINK v\u1eady.Ch\u1ec9 ti\u1ebfc r\u1eb1ng, BLACKPINK l\u1ea1i c\u00f3 m\u1ed9t m\u1ed1i duy\u00ean v\u1edbi nh\u00e2n v\u1eadt \u0111\u00ecnh \u0111\u00e1m th\u1ebf gi\u1edbi theo m\u1ed9t c\u00e1ch kh\u00f4ng th\u1ec3 t\u00ecnh c\u1edd b\u1ea5t ng\u1edd h\u01a1n th\u1ebf n\u00e0y... \u0110\u00f3 ch\u00ednh l\u00e0\u00a0. V\u00f4 t\u00ecnh\u00a0\u00a0\u0111\u00e3 va ph\u1ea3i v\u00e0o b\u1ee9c \u1ea3nh m\u00e0 Justin Bieber \u0111\u0103ng l\u00ean instagram ng\u00e0y h\u00f4m nay, th\u1ebf l\u00e0 l\u1ea1i t\u1ef1 nhi\u00ean chi\u1ebfm h\u1ebft spotlight b\u00e0n t\u00e1n c\u1ee7a ng\u01b0\u1eddi ta.B\u00ean d\u01b0\u1edbi ph\u1ea7n b\u00ecnh lu\u1eadn c\u1ee7a b\u1ee9c \u1ea3nh...C\u00e1c fan \u0111\u1ec1u d\u1ed3n s\u1ef1 ch\u00fa \u00fd v\u00e0o h\u00ecnh \u1ea3nh 2 th\u00e0nh vi\u00ean c\u1ee7a BLACKPINK."}}]}}
    print(json.dumps(data))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Elastic Search')
    parser.add_argument('-i', '--index_name', type=str, required=True, help='Index Name')
    parser.add_argument('-l', '--load_data', type=str, help='Create and load data by import json file to index - yes')
    parser.add_argument('-s', '--search', type=str, help='Search query. - query')
    args = parser.parse_args()
    
    es = connect_elasticsearch()
    if (args.search):
        search()