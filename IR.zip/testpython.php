<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style> 
input[type=text] {
  width: 100%;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}
</style>
</head>
<body>
<?php 
	if (isset($_GET['search']) && $_GET['search']) {
		if (getExistData($_GET['search'])) {
			$data = getExistData($_GET['search']);
			$output = $data->value;
		} else {
			$output = getNewData($_GET['search']);
		}
	}
	function getExistData($key) {
		if (file_exists("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt")) {
			$fileData = file_get_contents("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt");
			$dataArray = explode("***", $fileData);
			foreach ($dataArray as $item) {
				$item = json_decode($item);
				if (isset($item->key) && $item->key == $key) {
					return $item;
				}
			}
			return false;
		}
	}
	function getNewData($key) {

		//test _search.json
		// $stringData = file_get_contents("_search.json");

		//  python.py path
		$command = "py D:\Python\heightPredict.py -i index_name -s ". $key;
		$stringData = shell_exec($command);

		
		if ($stringData != '') {
			$jsonData = json_decode($stringData);
			$data = '{"key": "'.$key.'","value": '.$stringData.'}';

			// chrome cache path
			if (file_exists("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt")) {
				$item = "***".$data;
				file_put_contents("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt", $item, FILE_APPEND);
			} else {
				$item = $data;
				$keysearch = fopen("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt", "w");
				fwrite($keysearch, $item);
				fclose($keysearch);
			}
		}
		return $jsonData;
	}
?>
<div class="container">
	<div align="center"><h2><a href="testpython.php" style="text-decoration: none;color: green">Elastic Search</a></h2></div><br>
	<div  align="center">
		<form style="width: 50%">
			<input type="text" name="search" placeholder="Search.." id="search" style="">
			<button type="submit" name="submit" style="display: none;" id="submit">Search</button>
		</form>	
		<div id="suggest"></div>
	</div><br>
	
	<div id="result">
		<?php
			if ( isset($output)) {
				$text = '<hr style="width: 100%;color: 2px solid #ccc;"><div class="items">';
				foreach ($output->hits->hits as $item) {
					$text .= "<div class='".$item->_id."'><a href='".$item->_source->html."' id='".$item->_id."'><h2><b>".$item->_source->title."</b></h2></a><a style='text-decoration:none' href='".$item->_source->html."'><small style='color:blue'>".$item->_source->html."</small></a>";
					$text .= "<p class='short".$item->_id."'>".$item->_source->short_content."</p><small style='color:#ccc'>".$item->_source->time."</small></div><br>";
				}
				$text .= "</div>";
				echo $text;
			} elseif(isset($_GET['search'])) {
				echo '<div><h2 style="color:#ccc; text-align:center">No results</h2></div>';
			}
		?>
	</div>
</div>

<script>
	// function populatePre(url) {
	//     var xhr = new XMLHttpRequest();
	//     xhr.onload = function () {
	//     	var data = this.responseText;
	//         document.getElementById('suggest').textContent = suggestion;
	//     };
	//     xhr.open('GET', url);
	//     xhr.send();
	// }
	// populatePre('http://127.0.0.1/keysearch.txt');
	$( "#search" ).on('keyup',function(e) {
	    if(e.which == 13) {
	        if ($("#search").val() == "") {
	        	$( "#submit" ).attr("disabled", "false");
	        } else $("#submit"). removeAttr("disabled");
	    } else {
	    	// if ($("#search").val() != '') {
	    		$.ajax({
				   	url:'ajax.php',
				   	data:{key:$("#search").val()},
				   	method:'GET',
				   	success:function(response){
				   		var text = '';
				   		if (response != '') {
				   			response = response.split("***");
				   			var count = response.length;
				   			if ( count > 4) {
				   				count = 4;
				   			}
				   			text += '<div style="border:2px solid #ccc;width: 50%;text-align:left">';
				   			for (var i = 0; i < count; i++) {
				   				if (response[i] != '') {
				   					text += '<li style="padding:8px;font-size:16px;margin-left:30px;list-style:none;cursor:pointer"><a href="testpython.php?search='+response[i]+'">'+response[i]+'</a></li>';
				   				}
				   			}
				   			text += '</div>';
				   		}
				   		document.getElementById("suggest").innerHTML = text;
				   	}
			  	});
	    	// }
	    }

	});
	function hideItem(id) {
		for(var i=0; i <10; i++) {
			if (i != id) {
				$("."+i).css("display","none");
				$(".content"+id).removeAttr("style");
				$(".short"+id).css("display","none");
			}
		}
	}
	window.onload = function() {
	    var hideSuggest = document.getElementById('suggest');
	    document.onclick = function(e) {
	        if(e.target.id !== 'suggest'){
	            hideSuggest.style.display = 'none';
	        } 
	        if(e.target.id == 'search') {
	            hideSuggest.style.display = 'block';
	        } 
	    };
	};
</script>
</body>
</html>
