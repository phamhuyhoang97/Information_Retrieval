<?php
if (isset($_GET['key'])) {
	$data = file_get_contents("C:\Users\Hieu\AppData\Local\Google\Chrome\User Data/Profile 4\Cache\keysearch.txt");
	$dataArray = explode("***", $data);
	
	foreach ($dataArray as $item) {
		$item = json_decode($item);
		if ($_GET['key'] == '') {
			echo $item->key . "***" ;
		} else {
			if (isset($item->key) && strpos($item->key, $_GET['key']) !== false) {
				echo $item->key . "***" ;
			}
		}
	}
}
?>